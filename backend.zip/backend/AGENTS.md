# AGENTS.md - Instrucciones para agentes de OpenCode

Este archivo proporciona guías compactas y específicas del repositorio para los agentes de OpenCode. Cada línea responde: "¿Un agente probablemente perdería esto sin ayuda?"

## Consignas Transversales (obligatorias para todos los agentes)

- **Sin documentación mediante comentarios**: Al desarrollar código, evite cualquier tipo de documentación mediante comentarios (no agregue comentarios explicativos, bloques de documentación ni JSDoc a menos que lo pida explícitamente el usuario). Que el código se explique por sí mismo mediante nombres claros.
- **Consultar antes de cambiar**: Evite hacer cambios en el proyecto sin antes consultar al usuario. Ante dudas sobre qué modificar, cómo eliminar o dónde implementar, pregunte primero y espere confirmación.
- **Respetar la arquitectura limpia siempre**: En todo momento respete los principios de Clean Architecture (regla de dependencia, separación de capas, independencia de frameworks). Nunca sacrifique la arquitectura por conveniencia.
- **Explicar implementaciones futuras y su valor**: Antes o después de proponer cambios, explique las implementaciones futuras previstas y el valor que aportan al proyecto (qué problema resuelven, qué mejoran, por qué conviene hacerlas).

## Reglas Generales para Todos los Agentes

- **Respetar la cadena**: Ejecutar `lint -> typecheck -> test` en ese orden cuando se necesite una verificación completa. No omitir pasos.
- **Verificar codegen**: Antes de escribir código nuevo, verificar que `npm run codegen` o el equivalente ya no genere lo que está por escribir.
- **Límites del monorepo**: Este repositorio usa estructura de monorepo. Verificar los límites de paquetes con `ls packages/` o `ls apps/` antes de asumir la propiedad de un archivo.
- **Puntos de entrada de tests**: Los tests se ejecutan con `npm test` o `yarn test`. Para un solo paquete: `cd packages/<name> && npm test`.
- **Archivos env**: Nunca commitear archivos `.env`. Cargar desde `.env.example` o la configuración de `dotenv`. Nunca hardcodear secretos.
- **Servidor de desarrollo**: Ejecutar `npm run dev` o `yarn dev` para iniciar el servidor de desarrollo. No iniciar puertos manualmente.
- **Artefactos de build**: `dist/`, `build/` y `coverage/` están en gitignore. Regenerar con `npm run build`; no editar los artefactos de build a mano.
- **Flujo de CI**: CI ejecuta `lint → typecheck → test → build`. Si algún paso falla, el PR queda bloqueado. Corregir el paso anterior primero.

## Directrices de Arquitectura Limpia (para este repositorio)

- **Entidades**: Lógica de negocio pura. Sin frameworks, sin imports de DB. Importar desde `src/core/entities/`.
- **Casos de uso**: Orquestan el flujo de datos. Importan entidades como dependencias. Ubicados en `src/core/usecases/`.
- **Adaptadores de interfaz**: Controllers/repos traducen entre frameworks externos y casos de uso internos. Mantenerlos delgados.
- **Independencia de frameworks**: El núcleo NO tiene imports de frameworks. Web, DB y servicios externos están confinados a las capas externas.
- **Inyección de dependencias**: Las dependencias fluyen hacia adentro. Los casos de uso dependen de repositorios/entidades, no al revés.

## Ante la Duda

- Preguntarse: "¿Un agente probablemente perdería esto sin ayuda?" Si la respuesta es no, omitirlo.
- Preferir fuentes ejecutables (scripts, configs) sobre prosa.
- Revisar primero los scripts de `package.json`: son la fuente de verdad de los comandos.
- Si la arquitectura no está clara, inspeccionar los archivos de wiring (index.ts, app.entrypoint, etc.) antes de tocar archivos hoja.
